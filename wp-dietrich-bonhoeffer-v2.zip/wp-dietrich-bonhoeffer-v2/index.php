<?php
get_header();



if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		//
		// Post Content here
		//
	} // end while
} // end if

?>


<video autoplay muted loop id="myVideo">
	<source src="<?php bloginfo('template_url'); ?>/content/bg.mp4" type="video/mp4">
</video>


<div class="content">
	<h1>Church Dresden</h1>
</div>



<?php
get_footer();
?>
