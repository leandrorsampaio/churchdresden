<footer class="footer">
  <div class="footer-wraper default-width-wrapper">





    <div class="footerlogos">
      <div class="footerlogos-item logo-gge">
        <img src="<?php bloginfo('template_url'); ?>/img/logo-gge.jpg" alt="GGE logo German"/>
      </div>
    </div>







    <span class="translated-content lang-de">
      <p>
        2019 - Alle Rechte vorbehalten
      </p>
    </span>
    <span class="translated-content lang-en">
      <p>
        2019 - All rights reserved
      </p>
    </span>
    <span class="translated-content lang-es">
      <p>
        2019 - Todos los derechos reservados
      </p>
    </span>









  </div>
</footer>





</div><!-- class="wrapper" -->


<?php wp_footer(); ?>

</body>

</html>
